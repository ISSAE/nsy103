
	#include <stdio.h>

	int
main (void)
{
	char c;

	puts ("Je vais me planter d�s que vous aurez entr� un chiffre\n");

	return (scanf ("%lf", & c) == 1);
}
