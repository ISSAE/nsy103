
	#include <stdio.h>

	int
main (void)
{
	char chaine [128];

	return (gets (chaine) != NULL);
}
