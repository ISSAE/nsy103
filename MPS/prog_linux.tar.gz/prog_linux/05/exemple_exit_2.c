	#include <stdlib.h>

	void
main (void)
{
	exit (EXIT_SUCCESS);
}

