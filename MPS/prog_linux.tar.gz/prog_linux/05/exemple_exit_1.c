	#include <stdlib.h>

	void	sortie (void);

	int
main (void)
{
	sortie ();
}

	void
sortie (void)
{	
	exit (EXIT_FAILURE);
}
