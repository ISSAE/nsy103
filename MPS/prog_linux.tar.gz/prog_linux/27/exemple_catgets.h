#define second_Set 0x2	/* exemple_catgets.msg:11 */
#define second_chaine_1 0x1	/* exemple_catgets.msg:12 */
#define second_chaine_2 0x2	/* exemple_catgets.msg:13 */

#define premier_Set 0x1	/* exemple_catgets.msg:4 */
#define premier_chaine_1 0x1	/* exemple_catgets.msg:5 */
#define premier_chaine_2 0x2	/* exemple_catgets.msg:6 */
