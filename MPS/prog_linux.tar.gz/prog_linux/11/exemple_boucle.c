
	#include <unistd.h>

	int
main (void)
{
	alarm (5);
	while (1)
		;
	return (0);
}
